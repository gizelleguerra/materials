select t5.*, event_date, ecu_dtc
from 
(
select t3.vin, model_year, engine, full_part_number, part_prefix, part_base, part_suffix, part_desc, mli, ro_date
from
(
select vin, full_part_number, part_prefix, part_base, part_suffix, part_desc, mli, ro_date
from
(
select UD0B05_CNTRY_ISO3_C, UD0B05_PA_C, UD0B05_DLR_SUB_C, UD0B05_REPAIR_ORD_R, UD0B05_REPAIR_ORD_OPEN_Y as ro_date, 
UD0B05_VIN_C as vin, UD0B07_PART_R as full_part_number, UD0B07_PART_PREF_C as part_prefix, UD0B07_PART_BSE_C as part_base, 
UD0B07_PART_SFX_C as part_suffix, UD0B07_PART_X as part_desc from   
(
select UD0B05_CNTRY_ISO3_C, UD0B05_PA_C, UD0B05_DLR_SUB_C, UD0B05_REPAIR_ORD_R, UD0B05_REPAIR_ORD_OPEN_Y, UD0B05_VIN_C,
UD0B06_SVC_JOB_R, UD0B06_SVC_SEQ_R from
(select UD0B05_CNTRY_ISO3_C, UD0B05_PA_C, UD0B05_DLR_SUB_C, UD0B05_REPAIR_ORD_R, UD0B05_REPAIR_ORD_OPEN_Y, UD0B05_VIN_C
from GUDB_USA_R_View.SUD0B05_REPAIR_ORD_HDR
where UD0B05_CNTRY_ISO3_C = 'USA' and UD0B05_SKP_RPTG_F != 'Y') a
inner join
(select UD0B06_CNTRY_ISO3_C, UD0B06_PA_C, UD0B06_DLR_SUB_C, UD0B06_REPAIR_ORD_R, UD0B06_REPAIR_ORD_OPEN_Y, UD0B06_SVC_JOB_R,
UD0B06_SVC_SEQ_R, UD0B06_SVC_REACT_CATG_C
from GUDB_USA_R_View.SUD0B06_REPAIR_ORD_LBR
where UD0B06_CNTRY_ISO3_C = 'USA' and UD0B06_SVC_SEQ_R = 0 and trim(UD0B06_DER_REPAIR_C) in ('C','W','A','F','I')
and trim(UD0B06_SVC_REACT_CATG_C) NOT IN ("", "00", "05", "15", "18")
) b
on a.UD0B05_CNTRY_ISO3_C = b.UD0B06_CNTRY_ISO3_C
and a.UD0B05_PA_C = b.UD0B06_PA_C
and a.UD0B05_DLR_SUB_C = b.UD0B06_DLR_SUB_C
and a.UD0B05_REPAIR_ORD_R = b.UD0B06_REPAIR_ORD_R
and a.UD0B05_REPAIR_ORD_OPEN_Y = b.UD0B06_REPAIR_ORD_OPEN_Y
) c    
inner join
(select UD0B07_CNTRY_ISO3_C, UD0B07_PA_C, UD0B07_DLR_SUB_C, UD0B07_REPAIR_ORD_R, UD0B07_REPAIR_ORD_OPEN_Y, UD0B07_SVC_JOB_R,
UD0B07_PART_SEQ_R, UD0B07_PART_R, UD0B07_PART_PREF_C, UD0B07_PART_BSE_C, UD0B07_PART_SFX_C, UD0B07_PART_X
from GUDB_USA_R_View.SUD0B07_REPAIR_ORD_PART
where UD0B07_PART_TRANSACT_C != 'C') d
on c.UD0B05_CNTRY_ISO3_C = d.UD0B07_CNTRY_ISO3_C
and c.UD0B05_PA_C = d.UD0B07_PA_C
and c.UD0B05_DLR_SUB_C = d.UD0B07_DLR_SUB_C
and c.UD0B05_REPAIR_ORD_R = d.UD0B07_REPAIR_ORD_R
and c.UD0B05_REPAIR_ORD_OPEN_Y = d.UD0B07_REPAIR_ORD_OPEN_Y
and c.UD0B06_SVC_JOB_R = d.UD0B07_SVC_JOB_R
) t1
inner join
(
select ud0r07_pckd_part_r, ud0r07_part_prod_c as mli, ud0r07_part_grp_c, ud0r07_part_sub_grp_c
from GUDB_USA_R_View.sud0r07_partsrce_ref
where trim(ud0r07_src_1st_c) = 'MMP'
) t2
on t1.full_part_number = t2.ud0r07_pckd_part_r
where trim(mli) not in ('38AN','38BC','38BD','38BF','38BB','38SB','38AD','38AJ','38AL','38BP','38XL','88BC',
'91BD','49BD','77BD','78BD','13AE','15BA','15BD','15BG','15BF','15BQ','87HT','88HT','89HT','38MO','38MP','38MS',
'41LC','41LM','02OK','01ON') and substr(mli, 1, 2) != '99'
) t3
inner join
(
select vin, model_year, engine from 60361_bz0009_pd_vin2x_bztz_db.vin_dimension
where model_year in (2018, 2019, 2020, 2021) and nameplate = 'F-150' and latest_dealer_country in ('USA') 
and warranty_start_date is not null
) t4
on t3.vin = t4.vin
) t5
inner join
(select cvdcvt_vin_d_3, date(cvdcvt_event_s_3) as event_date, cvdcvt_ecu_d_2||'_'||cvdcvt_dtc_d_2||'_'||cvdcvt_dtc_info_byte_x_2 as ecu_dtc
from cvdp.ncvdvcf_dtc_summary_na_usa_lmi_vw
where cvdcvt_wrng_ind_reqstd_r_2 = 1) t6
on t5.vin = cvdcvt_vin_d_3
where datediff(ro_date, event_date) > 0 and datediff(ro_date, event_date) < 30