import datetime          as dtm
import pandas            as pd
import numpy             as np

import random
import string

from   sklearn           import datasets, linear_model
from   pyspark.sql.types import Row

df      = spark.read.table('lguerra5.oil_life_algorithm_input')
o       = df.rdd.map(lambda r: oil_life_algorithm(r))
o       = o.map(lambda x: Row(**x))
df_o    = o.toDF()

#EU specific study
df_v    = spark.read.option('header', 'true').csv('eu_vins.csv')
df_j    = df_o.join(df_v, 'vin')
df_j.show()
df_j.write.mode('overwrite').option('header', 'true').csv('eu_results_2.csv')

df_o.select('vin', 'next_oil_change', 'next_oil_odometer', 'r_squared', 'num_samples').show()

#replace this with you own place to save output file
df_o.write.parquet('hdfs://hdp2cluster/user/lguerra5/prototype_model_output_full/oil_life_algorithm_output.parquet')

def oil_life_algorithm(r):
    # Initialize Pandas DataFrame
    df              = pd.DataFrame({'oil_change_cycle_number': r[0], 'trip_number': r[1], 'timeend2': r[2], 'oil_percent': r[3], 'odometer': r[4], 'vin': r[5]})
    # FILTER BY OIL LIFE % VALUE
    df['keep_values']               = df['oil_percent'] <= 100
	#df['keep_values']               = df['oil_percent'] <= 100 and 70 , then 100-60 then 100-50,40,30 ect and save the results for each,then use 70 for UB
	
    # OIL CHANGE CYCLE NUMBER SHIFT
    df                              = df.sort_values('trip_number', ascending=False)
    max_oil_change_cycle            = int(df['oil_change_cycle_number'].max())
    df['oil_change_detection']      = 0
    df['oil_change_detection']      = df['oil_change_cycle_number'].diff().abs()
    df['oil_percent_diff']          = 0
    df['oil_percent_diff']          = df['oil_percent'].diff().where(df['oil_change_detection'] == 1).abs()
    df['oil_change_diff']           = max_oil_change_cycle - df['oil_change_cycle_number']
    df                              = df.fillna(0)
    df['oil_percent_diff_cumsum']   = df.oil_percent_diff.cumsum()
    df['oil_percent_updated']       = df['oil_percent'] + df['oil_percent_diff_cumsum'] + df['oil_change_diff']
    drop_columns                    = ['oil_change_detection', 'oil_percent_diff', 'oil_change_diff','oil_percent_diff_cumsum', 'oil_percent', 'keep_values']
    df                              = df[df['keep_values'] == True]
    df                              = df.drop(columns=drop_columns)
    df                              = df.rename(columns={'oil_percent_updated': 'oil_percent'})
    df                              = df[['oil_change_cycle_number', 'trip_number', 'timeend2', 'oil_percent', 'odometer', 'vin']]
    if (df.empty): return {'vin': ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(17)), 'next_oil_change': dtm.date(1970, 1, 1), 'next_oil_odometer': int(0), 'r_squared': float(-10000.0), 'num_samples': int(0)}
    # Add Column 'date' in Correct Format
    df.insert(5, "date", pd.to_datetime(df.timeend2).astype('datetime64[ns]'))
    # Initialize DataFrame for Algorithm
    df_interval_first = df
    # Initialize Parameters
    w_exp_seed      = 1.05                          # Exponential Weight: Seed
    start_date      = dtm.datetime.utcnow().date()  # Today's Date
    start_date_np   = np.datetime64(start_date)     # Today's Date
    # Initialize Variables
    w               = np.zeros(1)                   # Linear Regression: Slope
    b               = np.zeros(1)                   # Linear Regression: Bias
    # Import Oil Life % Values into numpy Array
    oil_percent     = df_interval_first.oil_percent.values
    oil_percent     = oil_percent.reshape(-1,1)
    # Compute Time Delta Between df_interval_first and start_date (in Days)
    t               = (df_interval_first.date - start_date_np).dt.days.values
    t               = t.reshape(-1, 1)
    # Compute Exponential Weighting to Ensure Recent Data Is More Important
    w_exp           = np.array([np.power(w_exp_seed, p) for p in t.reshape(-1)])
    w_exp           = np.array(w_exp / sum(w_exp))
    # Compute Linear Regression Model
    regr_oil        = linear_model.LinearRegression(fit_intercept=True)
    regr_oil.fit(oil_percent, t, sample_weight=w_exp)
    # If Regression Line Is Nearly Flat, Set b = 365;
    # Else, Compute d via the Linear Regression Model
    if regr_oil.coef_[0] <= -3.65:
        b[0]    = 365
    else:
        b[0]    = regr_oil.intercept_[0]
    w[0]    = regr_oil.coef_[0]
    # Return Predicted Date for Next Oil Change
    next_oil_change     = start_date + dtm.timedelta(days=b[0])
    # Return r-Squared Value
    r_squared           = regr_oil.score(oil_percent, t)
    # Return Number of Samples
    num_samples         = oil_percent.size
    # Import Odometer Values into numpy Array
    odometer            = df_interval_first.odometer.values
    odometer            = odometer.reshape(-1, 1)
    # Compute Linear Regression Model
    regr_odometer       = linear_model.LinearRegression(fit_intercept=True)
    regr_odometer.fit(odometer, t, sample_weight=w_exp)
    # Compute the Number of Days to Next Oil Change
    # NOTE: You Can Choose Any Value of next_oil_days to Determine Prediction of Odometer Reading at that Value
    # next_oil_days       = (next_oil_change - start_date).days
    next_oil_days       = b[0]
    # Return Predicted Odometer for Next Oil Change
    if regr_odometer.coef_ >= 0.0001:
        next_oil_odometer   = (next_oil_days - regr_odometer.intercept_) / regr_odometer.coef_
        next_oil_odometer   = next_oil_odometer[0][0]
    else:
        next_oil_odometer   = -1
    return {'vin': str(df.iloc[0, 6]), 'next_oil_change': next_oil_change, 'next_oil_odometer': int(next_oil_odometer), 'r_squared': float(r_squared), 'num_samples': int(num_samples)}
