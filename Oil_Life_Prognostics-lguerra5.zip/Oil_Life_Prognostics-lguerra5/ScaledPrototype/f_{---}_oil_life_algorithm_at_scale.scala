import org.apache.spark.sql.expressions.Window
import spark.implicits._

//pre-processing module option
var df  = spark.read.parquet("/user/lguerra5/pae_processing_prod/trip_summary_preprocessed_subset/*")

//filter for first oil life cycle only
//df = df.filter(df.oil_change_cycle_number == 1)

//direct from table method
//var df  = spark.read.table("lguerra5.oil_life_algorithm_at_scale")

    df  = df.withColumn("arr_oil_change_cycle_number",  collect_list("oil_change_cycle_number" ).over(Window.partitionBy("vin").orderBy(col("trip_number").desc)))
    df  = df.withColumn("arr_trip_number",              collect_list("trip_number"             ).over(Window.partitionBy("vin").orderBy(col("trip_number").desc)))
    df  = df.withColumn("arr_trip_end_date",            collect_list("trip_end_date"           ).over(Window.partitionBy("vin").orderBy(col("trip_number").desc)))
    df  = df.withColumn("arr_trip_end_eng_oil_percent", collect_list("trip_end_eng_oil_percent").over(Window.partitionBy("vin").orderBy(col("trip_number").desc)))
    df  = df.withColumn("arr_trip_end_odo_read",        collect_list("trip_end_odo_read"       ).over(Window.partitionBy("vin").orderBy(col("trip_number").desc)))

    df  = df.groupBy("vin").agg(max("arr_oil_change_cycle_number").as("arr_oil_change_cycle_number"), max("arr_trip_number").as("arr_trip_number"), max("arr_trip_end_date").as("arr_trip_end_date"), max("arr_trip_end_eng_oil_percent").as("arr_trip_end_eng_oil_percent"), max("arr_trip_end_odo_read").as("arr_trip_end_odo_read"))
    df  = df.select(col("arr_oil_change_cycle_number") as "oil_change_cycle_number", col("arr_trip_number") as "trip_number", col("arr_trip_end_date") as "trip_end_date", col("arr_trip_end_eng_oil_percent") as "trip_end_eng_oil_percent", col("arr_trip_end_odo_read") as "trip_end_odo_read", col("vin"))

    df.write.mode("overwrite").saveAsTable("lguerra5.oil_life_algorithm_input")
