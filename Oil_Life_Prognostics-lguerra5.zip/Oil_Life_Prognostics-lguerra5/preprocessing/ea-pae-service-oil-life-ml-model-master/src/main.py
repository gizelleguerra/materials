#!/usr/bin/env python

"""
This project trains an oil life machine learning model in batch, and is part of the Prognostics Analytics Engine (PAE)
application.  It is invoked via a daily Oozie workflow.
"""
import argparse
import configparser
from pyspark.sql import SparkSession
from pyspark import SparkContext

#from jobs.oil_life_model.OilLifeModelBatchTraining import OilLifeModelBatchTraining
from jobs.preprocessing_data_for_training.DataPreparation import DataPreparation
#from jobs.call_procedure.ExecuteProcedure import ExecuteProcedure
#rom jobs.convert_test_data.ConvertTestData import ConvertTestData
#from jobs.fetch_limit_mappings.FetchLimitMappings import FetchLimitMappings
#from logs.logging_factory import LoggingFactory


def parse_args():
    parser = argparse.ArgumentParser(description='PAE Oil Life ML Model Training')
    subparsers_task = parser.add_subparsers(dest='task', title='task')
    subparsers_task.required = True
    subparsers_task.add_parser(
        'fetch_limit_mappings',
        help='Rebuilds tables for mapping strategies/intervals/VINs for upper limit calculations. '
             'Currently supported in EU application config files only. '
    )
    subparsers_task.add_parser(
        'callprocedure',
        help='Initializes necessary session and schema variables that are required throughout the scope.'
    )
    subparsers_task.add_parser(
        'preprocessing',
        help='Cleans historical vehicle data to prepare for executing oil life model training.'
    )
    parser_convert_testing_data = subparsers_task.add_parser(
        'convert_test_data',
        help='Retrieves trip summary data from the training test table, and stores it in Parquet format for training. '
             'See subcommand help (main.py convert_test_data -h). '
    )
    parser_convert_testing_data.add_argument(
        '--test-id',
        dest='convert_test_data_id',
        required=True,
        help='The ID of the test data row to be consumed from the training test table. '
    )
    parser_training = subparsers_task.add_parser(
        'training',
        help='Trains the PAE oil life model for each tracked vehicle. '
             'See subcommand help (main.py training -h). '
    )
    parser_training.add_argument(
        '--use-test-data',
        dest='training_test_data_id',
        help='Uses trip summary data from the test data associated with the given test data ID. '
             'This data is imported from the converttestdata subcommand, using the same test data ID. '
             'If omitted, then the oil life model is trained on the usual daily batch training data. '
    )
    return parser.parse_args()


def main():
    """
    Main starting point of the application
    """
    args = parse_args()
    selected_task = None
    option = args.task
    convert_test_data_id = None
    training_test_data_id = None
    if option == 'fetch_limit_mappings':
        selected_task = 'fetching limit mappings'
    elif option == 'preprocessing':
        selected_task = 'historical data pre-processing'
    elif option == 'convert_test_data':
        selected_task = 'testing data conversion'
        convert_test_data_id = args.convert_test_data_id
    elif option == 'training':
        selected_task = 'oil life model training'
        training_test_data_id = args.training_test_data_id
    elif option == 'callprocedure':
        selected_task = 'call stored procedure'

    # load the application logging configuration
    #logging_factory = LoggingFactory()
    #logger = logging_factory.get_logger(__name__)

    #logger.info('Starting %s process', selected_task)
    try:
        # Read config params from file
        config = configparser.ConfigParser()
        with open('application-config.ini') as config_file:
            config.read_file(config_file)

        # Create the Spark session and Spark context
        spark = SparkSession.builder.appName("PAE_" + option).enableHiveSupport().getOrCreate()
        sc = spark.sparkContext

        if option == 'fetch_limit_mappings':
            hive = __get_hive_session(spark)
            app_id_file_path = config.get('Yarn', 'app_id_fetch_limit_mappings_file_path')
            fetch_limit_mappings = FetchLimitMappings(spark, hive, config)
            fetch_limit_mappings.main()
        elif option == 'preprocessing':
            hive = __get_hive_session(spark)
            app_id_file_path = config.get('Yarn', 'app_id_preprocessing_file_path')
            data_preprocessing = DataPreparation(spark, hive, config)
            data_preprocessing.main()
        elif option == 'convert_test_data':
            app_id_file_path = config.get('Yarn', 'app_id_convert_test_data_file_path')
            data_convert_test_data = ConvertTestData(spark, config, convert_test_data_id)
            data_convert_test_data.main()
        elif option == 'training':
            app_id_file_path = config.get('Yarn', 'app_id_file_path')
            oil_model = OilLifeModelBatchTraining(spark, config, training_test_data_id)
            oil_model.main()
        elif option == 'callprocedure':
            app_id_file_path = config.get('Yarn', 'app_id_call_procedure_file_path')
            call_procedure = ExecuteProcedure(spark, config)
            call_procedure.main()
        else:
            app_id_file_path = None

        app_id = sc.applicationId
        fs = sc._jvm.org.apache.hadoop.fs.FileSystem.get(sc._jsc.hadoopConfiguration())
        file_os = fs.create(sc._jvm.org.apache.hadoop.fs.Path(app_id_file_path), True)
        file_os.writeBytes(app_id)
        file_os.flush()
        file_os.close()

        #logger.info('%s completed successfully', selected_task.capitalize())
        spark.stop()

    except Exception as error:
        #logger.exception('Exception occurred during %s process!', selected_task)
        raise error


def __get_hive_session(spark):
    from pyspark_llap.sql.session import HiveWarehouseSession
    return HiveWarehouseSession.session(spark).build()


if __name__ == "__main__":
    main()