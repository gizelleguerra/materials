
#!/usr/bin/env python

from configparser import ConfigParser

import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.types import *
import re

#from logs.logging_factory import LoggingFactory


class DataPreparation:
    """
    Invoked daily to clean historical vehicle data prior to executing oil life model training on the clean data.
    """

    def __init__(self,
                 spark_session: SparkSession,
                 hive_session,
                 config_parser: ConfigParser):
        #self.logger = LoggingFactory().get_logger(__name__)
        self.spark = spark_session
        self.hive = hive_session
        self.config = config_parser
        self.trip_summary_raw_data_df = None

    def preprocess_data_for_training(self, num_partitions):
        """
        Entry point to batch processing of trip summary data. Invokes necessary private methods to follow the
        pre-processing steps.

        :param num_partitions: Number of partitions the input data frame should be divided into while processing
        :return: A PySpark RDD containing the cleaned historical data
        :rtype: pyspark.RDD
        """
        try:
            processed_vin_df = []

            def preprocess_trip_summary_in_batch(vin_partition):
                """
                Invoked via the pyspark.RDD.mapPartitions method.  This method is run by an individual Spark executor
                to clean the historical trip data of certain VINs.

                :param vin_partition: An iterator over the rows of data sent to this executor
                :return: A PySpark RDD containing the cleaned data of the vehicles sent to this executor
                :rtype: pyspark.RDD
                """

                """
                Constants Used In Data Cleaning:
                We want to verify that we don't see a sudden, drastic drop in oil % immediately after receiving a value
                of 100. This could indicate that the 100 reading is not reliable, and may be caused by a bad signal
                from the vehicle. It will almost certainly require several trips for the oil % to drop to 97 and then
                94.  Therefore, if the trips immediately following show greater drops than these, we cannot reliably
                conclude that the 100 value we saw indicates an oil reset.
                """
                max_oil_percent = 100

                #logger = LoggingFactory().get_logger(__name__)
                #logger.info('Converting partition to dictionary')
                filtered_row_list = (row_.asDict() for row_ in vin_partition)

                #logger.info('Converting dictionary to Pandas data frame')
                pd_df = pd.DataFrame(filtered_row_list, columns=['oil_change_cycle_number', 'trip_number',
                                                                 'trip_end_time', 'trip_end_eng_oil_percent',
                                                                 'trip_end_odo_read', 'vin'])

                pd_df['trip_end_date'] = pd.to_datetime(pd_df['trip_end_time']).apply(lambda x: x.date())

                pd_df = pd_df.drop(columns=['trip_number','trip_end_time'])

                #logger.info('Grouping partition data frame by VIN')
                grouped_df = pd_df.groupby('vin')

                #logger.info('Iterating grouped VIN')
                for group in grouped_df:
                    vin = group[0]
                    vin_df = group[1]

                    #logger.debug('Starting processing for VIN %s', vin)

                    def has_oil_changed(val):
                        """
                        The purpose of this method is to safeguard against fluctuations in the the oil percentage
                        reported by the vehicle. This method examines a row whose oil percent value is 100, and does
                        pattern matching against its neighbors to determine whether the row should be flagged as
                        representing an oil reset.  If the oil has been changed, return 1, otherwise return 0.

                        :param val: A single row in the VIN's data frame.  The row's oil % value is 100.
                        :return: 1 if the row is the first record of a new oil cycle; 0 otherwise
                        """
                        index = -1
                        if pd.notna(val.index_col):
                            index = int(val.index_col)
                        oil_percent_at_current_index = val['trip_end_eng_oil_percent']

                        #Threshold value for oil reset detection at 100
                        oil_decrease_threshold_1 = 97
                        oil_decrease_threshold_2 = 94

                        # Threshold value for oil reset detection at spike
                        delta_1 = 3
                        delta_2 = 6

                        # check if there are at least 3 previous trips for this VIN in the data frame
                        # we will need the 2 most recent trips
                        if index > 2:
                            oil_percent_at_previous_index = vin_df.loc[vin_df['index_col'] == index - 1,
                                                                       'trip_end_eng_oil_percent'].iloc[0]
                            oil_percent_at_previous_index_2 = vin_df.loc[vin_df['index_col'] == index - 2,
                                                                         'trip_end_eng_oil_percent'].iloc[0]

                            # if the current row's oil life has increased from the last 2 values, examine the value
                            # in the following row
                            if oil_percent_at_previous_index < oil_percent_at_current_index and \
                                                     oil_percent_at_previous_index_2 < oil_percent_at_current_index:
                                index += 1

                                # If the following row shows oil life greater than or equal to 97%, AND the row after
                                # the next shows it greater than or equal to 94%, we "turn on" the oil reset flag
                                # (i.e. set it to 1). Otherwise, the current row does not represent an oil reset
                                # (i.e. set it to 0).
                                if index in vin_df.index_col:
                                    oil_percent_at_this_index = vin_df.loc[vin_df['index_col'] == index,
                                                                           'trip_end_eng_oil_percent'].iloc[0]
                                    if oil_percent_at_current_index == 100:
                                        if oil_percent_at_this_index >= oil_decrease_threshold_1:
                                            index += 1
                                            if index in vin_df.index_col:
                                                oil_percent_at_this_index = vin_df.loc[vin_df['index_col'] == index ,'trip_end_eng_oil_percent'].iloc[0]
                                                if oil_percent_at_this_index >= oil_decrease_threshold_2:
                                                    #logger.debug('Setting oil reset flag for trip # %s' , index - 2)
                                                    return 1
                                    else:
                                        if oil_percent_at_current_index - oil_percent_at_this_index <= delta_1 and oil_percent_at_current_index - oil_percent_at_this_index >= 0:
                                            index += 1
                                            if index in vin_df.index_col:
                                                oil_percent_at_this_index = vin_df.loc[vin_df['index_col'] == index,'trip_end_eng_oil_percent'].iloc[0]
                                                if oil_percent_at_current_index - oil_percent_at_this_index <= delta_2 and oil_percent_at_current_index - oil_percent_at_this_index >= 0:
                                                    #logger.debug('Setting oil reset flag for trip # %s', index - 2)
                                                    return 1
                                    return 0
                        return 0

                    def update_oil_change_cycle_number(row):
                        """
                        This method re-calculates the oil change cycle number by doing a running sum over the
                        oil_change_flag column. As there is a value of 1 for each oil reset, the summation of the
                        preceding rows will yield the current oil cycle number, beginning with cycle 0.

                        :param row: A single row in the VIN's data frame
                        :return: The integer value, starting with 0, of the oil change cycle a row is associated with
                        """
                        index = 1
                        if pd.notna(row.index_col):
                            index = int(row.index_col)
                        if index - 1 in vin_df.index_col:
                            return vin_df[:index + 1]['oil_change_flag'].sum()
                        else:
                            return 0

                    dup_columns = ['trip_end_odo_read', 'trip_end_date', 'trip_end_eng_oil_percent',
                                   'oil_change_cycle_number']

                    #logger.debug('Sorting data frame by odo, trip end date, and oil percent, and dropping duplicates')

                    # Step 1: Sort the rows based on odometer, trip end date, oil percent, and remove duplicate rows
                    vin_df = vin_df.sort_values(by=['trip_end_odo_read', 'trip_end_date','trip_end_eng_oil_percent'],
                                                ascending=True).drop_duplicates(subset=dup_columns, keep='last')

                    # Re-number the rows (re-index them), and create a literal column for the index
                    vin_df = vin_df.reset_index(drop=True, inplace=False)
                    vin_df['index_col'] = vin_df.index

                    # Remove any row containing NaN values
                    vin_df = vin_df.dropna()

                    #logger.debug('Invoking has_oil_changed method for rows with 100% oil life')

                    # Step 2: Check if the oil has been changed either s 100 has been spotted or there is a delta of 30 or more
                    vin_df['oil_change_flag'] = vin_df.where((vin_df['trip_end_eng_oil_percent'] ==
                                                             max_oil_percent) | (vin_df['trip_end_eng_oil_percent'].diff() >= 30.0)).apply(has_oil_changed, axis=1)
                    vin_df = vin_df.fillna(0)

                    #logger.debug('Invoking update_oil_change_cycle_number method based on change detection column')

                    # Step 3: Update the oil change cycle number
                    vin_df['oil_change_cycle_number_updated'] = 0
                    vin_df['oil_change_cycle_number_updated'] = vin_df.apply(update_oil_change_cycle_number, axis=1)

                    # Drop the old oil change cycle column from SCA-V
                    vin_df = vin_df.drop(columns=['oil_change_cycle_number'])
                    # Rename the column names (index_col becomes the new trip_number column)
                    vin_df = vin_df.rename(columns={'oil_change_cycle_number_updated': 'oil_change_cycle_number',
                                                    'index_col': 'trip_number'})

                    #logger.debug('Adding columns for starting cycle values')

                    # Add columns to capture the starting oil life % for the most recent cycle, the starting odometer
                    # reading for the most recent cycle, and the date of the first trip in this vehicle's most recent
                    # oil change cycle.  These values are needed for oil life model training.
                    min_trip_number_of_max_oil_change_cycle = vin_df['trip_number'].where(
                        vin_df['oil_change_cycle_number'] == vin_df['oil_change_cycle_number'].max()).dropna().min()
                    vin_df['first_ol_pct'] = vin_df['trip_end_eng_oil_percent'].where(
                        vin_df['trip_number'] == min_trip_number_of_max_oil_change_cycle).dropna().values[0]
                    vin_df['first_odometer'] = int(vin_df['trip_end_odo_read'].where(
                        vin_df['trip_number'] == min_trip_number_of_max_oil_change_cycle).dropna().values[0])
                    vin_df['first_ol_date'] = vin_df['trip_end_date'].where(
                        vin_df['trip_number'] == min_trip_number_of_max_oil_change_cycle).dropna().values[0]

                    #logger.debug('Limiting number of samples to most recent 1500 trips')

                    # Retrieve the 1500 most recent data points (or all points if < 1500 samples)
                    #vin_df = vin_df.tail(1500)
                    # shorten historical data period
                    vin_df = vin_df.tail(400)
                    single_df_list = vin_df.values.tolist()
                    # Add the pre-processed data for this VIN to the list of all pre-processed vehicle data
                    processed_vin_df.extend(single_df_list)
                    #logger.debug('Finished processing for VIN %s', vin)

                #logger.debug('Finished processing for all VINs')
                return processed_vin_df

            #self.logger.debug('Re-partitioning historical data frame into %d partitions', num_partitions)
            vin_partitioned_dataframe = self.trip_summary_raw_data_df.repartition(num_partitions, 'vin')

            #self.logger.debug('Invoking mapPartitions on historical data frame')
            return vin_partitioned_dataframe.rdd.mapPartitions(preprocess_trip_summary_in_batch, True)
        except Exception as e:
            raise e

    def fetch_data_from_hive(self,
                             scav_db_for_trip_summary,
                             trip_summary_table,
                             countries,
                             trip_end_year_since):
        if not countries:
            raise ValueError('Missing country codes for fetching data from hive.')

        if not trip_end_year_since:
            raise ValueError('Trip End Year value is missing for fetching data from hive.')

        for country in countries:
            if not re.match('^[a-zA-Z]+$', country):
                raise ValueError(f"Invalid country code: '{country}'")

        # Remove trailing comma from tuple with length one
        countries_str = re.sub(r',\)$', ')', str(tuple(countries)))

        script_path = str(self.config['Hive_Query_Path']['hive_script'])

        # Save the loaded data to a member variable to prevent memory overhead incurred during the copy
        # operation resulting from returning data from a method
        with open(script_path) as hive_script_file:
            fetch_data_query = hive_script_file.read()
        fetch_data_query = fetch_data_query\
            .replace('${hivevar:TRIP_SUMMARY_DB}', scav_db_for_trip_summary)\
            .replace('${hivevar:TRIP_SUMMARY_VIEW}', trip_summary_table)\
            .replace('${hivevar:TRIP_SUMMARY_DATA_COUNTRIES}', countries_str) \
            .replace('${hivevar:TRIP_END_YEAR_SINCE}', trip_end_year_since)
        self.trip_summary_raw_data_df = self.hive.executeQuery(fetch_data_query)

    def write_dataframe_to_parquet(self, dataframe):
        preprocessed_parquet_path = self.config['Parquet_File_Path']['parquet_location'] + '/' \
                                    + self.config['Parquet_File_Path']['parquet_folder_name']
        dataframe.write.mode("Overwrite").parquet(preprocessed_parquet_path)

    def main(self):
        #self.logger.debug('Starting loading of historical data')

        scav_db_for_trip_summary = self.config['SCAV_Trip_Summary']['database']
        trip_summary_table = self.config['SCAV_Trip_Summary']['table_or_view']
        countries = self.config['Region']['countries'].strip().split(',')
        trip_end_year_since = self.config['Region']['trip_end_year_since']

        self.fetch_data_from_hive(
            scav_db_for_trip_summary,
            trip_summary_table,
            countries,
            trip_end_year_since)

        
        partition_length = int(self.config['Partition_Length']['partition_length'])
        
        #print(self.trip_summary_raw_data_df.show(10))

        #self.logger.debug('Starting pre-processing of historical data with partition_length=%s', partition_length)
        preprocessed_trip_summary_rdd = self.preprocess_data_for_training(partition_length)

        data_pre_processed_schema = StructType([
            StructField('trip_end_eng_oil_percent', FloatType()),
            StructField('trip_end_odo_read', LongType()),
            StructField('vin', StringType()),
            StructField('trip_end_date' , DateType()),
            StructField('trip_number', IntegerType()),
            StructField('oil_change_flag', IntegerType()),
            StructField('oil_change_cycle_number', IntegerType()),
            StructField('first_ol_pct', FloatType()),
            StructField('first_odometer', LongType()),
            StructField('first_ol_date', DateType())
        ])
        #self.logger.debug('Applying the following schema to pre-processed data: %s', str(data_pre_processed_schema))
        output_df = self.spark.createDataFrame(preprocessed_trip_summary_rdd, data_pre_processed_schema)

        #self.logger.debug('Saving pre-processed data to Parquet')
        self.write_dataframe_to_parquet(output_df)
        #print(output_df.show(10))