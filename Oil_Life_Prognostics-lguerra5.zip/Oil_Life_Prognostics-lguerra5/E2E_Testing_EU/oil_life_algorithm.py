import datetime as dtm
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os.path
import sys

from matplotlib.backends.backend_pdf import PdfPages
from sklearn import datasets, linear_model


def get_model_params(df):
    
    # Instantiate DataFrames
    df_interval = pd.DataFrame()
    df_interval_first = pd.DataFrame()

    # sort values in descending order to do oil cycle number shift
    df = df.sort_values('trip_number', ascending=False)

    # OIL CHANGE CYCLE NUMBER SHIFT - dont do if data doesnt have an oil change
    max_oil_change_cycle            = int(df['oil_change_cycle_number'].max())
    df['oil_change_detection']      = 0
    df['oil_change_detection']      = df['oil_change_cycle_number'].diff().abs()
    df['oil_percent_diff']          = 0
    df['oil_percent_diff']          = df['trip_end_eng_oil_percent'].diff().where(df['oil_change_detection'] == 1).abs()
    df['oil_change_diff']           = max_oil_change_cycle - df['oil_change_cycle_number']
    df                              = df.fillna(0)
    df['oil_percent_diff_cumsum']   = df.oil_percent_diff.cumsum()
    df['oil_percent_updated']       = df['trip_end_eng_oil_percent'] + df['oil_percent_diff_cumsum'] + df['oil_change_diff']
    drop_columns                    = ['oil_change_detection', 'oil_percent_diff', 'oil_change_diff','oil_percent_diff_cumsum', 'trip_end_eng_oil_percent']
    #df                              = df.query('trip_end_eng_oil_percent <= 75')
    df                              = df.drop(columns=drop_columns)
    df                              = df.rename(columns={'oil_percent_updated': 'trip_end_eng_oil_percent'})
    #df                              = df[['oil_change_cycle_number', 'trip_number', 'timeend2', 'trip_end_eng_oil_percent', 'trip_end_odo_read', 'vin']]

    # Add Column 'date' in Correct Format
    df.insert(5, "date", pd.to_datetime(df.timeend2).astype('datetime64[ns]'))

    # Select Pertinent Fields from df
    df_interval["trip_number"] = pd.Series(df.trip_number)
    df_interval["date"] = pd.Series(df.date)
    df_interval["odometer"] = pd.Series(df.trip_end_odo_read)
    df_interval["oil_percent"] = pd.Series(df.trip_end_eng_oil_percent)
    df_interval = df_interval.sort_values('trip_number')

    # Select Subset of Rows from df_interval
    df_interval_first = df_interval[(df_interval['trip_number'] <= 100000)]

    # # Predict Date of Oil Change
    # Initialize Parameters
    w_exp_seed = 1.05                          # Exponential Weight: Seed

    #in case we want to set the start date to a different date
    #start_date  = dtm.datetime(2019, 5, 28)
    start_date = dtm.datetime.utcnow().date()  # Today's Date
    start_date_np = np.datetime64(start_date)  # Today's Date

    # Initialize Variables
    w = np.zeros(1)                   # Linear Regression: Slope
    b = np.zeros(1)                   # Linear Regression: Bias

    # Import Oil Life % Values into numpy Array
    oil_percent = df_interval_first.oil_percent.values
    oil_percent = oil_percent.reshape(-1, 1)

    # Compute Time Delta Between df_interval_first and start_date (in Days)
    t = (df_interval_first.date - start_date_np).dt.days.values
    t = t.reshape(-1, 1)

    # Compute Exponential Weighting to Ensure Recent Data Is More Important
    w_exp = [np.power(w_exp_seed, p) for p in t.reshape(-1)]
    w_exp = np.array(w_exp / sum(w_exp))

    # Compute Linear Regression Model
    regr_oil = linear_model.LinearRegression(fit_intercept=True)
    regr_oil.fit(oil_percent, t, sample_weight=w_exp)

    # upper limit values (from table or just 16000 km/365 days for US vehicles) - Change for EU vehicles
    vehicle_odometer_limit = 15000
    vehicle_date_limit = 365

    # If Regression Line Is Nearly Flat, slope is less than -3.65, Set b = 365; - this is for US only
    # set to -7.30 due to updated 730 day limit for the EU test case
    # Else, Compute d via the Linear Regression Model
    if regr_oil.coef_[0] <= (-0.01*vehicle_date_limit):
        b[0] = vehicle_date_limit
    else:
        b[0] = regr_oil.intercept_[0]

    w[0] = regr_oil.coef_[0]
    w[0], b[0]

    # Return Predicted Date for Next Oil Change
    next_oil_change = start_date + dtm.timedelta(days=b[0])
    next_oil_change

    # Return r-Squared Value
    r_squared = regr_oil.score(oil_percent, t)
    r_squared

    # Return Number of Samples
    num_samples = oil_percent.size
    num_samples

    # *************************************************************
    # ************** computed weighted R squared ******************
    # *************************************************************
    t_pred = regr_oil.predict(oil_percent)
    weighted_mean = np.average(t, weights=w_exp.reshape([-1, 1]))
    SST = np.dot(w_exp, np.square(t-weighted_mean))
    SSE = np.dot(w_exp, np.square(t-t_pred))
    if SST != 0:
        weighted_r_squared = np.asscalar(1-SSE/SST)
    else:
        weighted_r_squared = 12345.0
    # *************************************************************
    # *************************************************************
    # *************************************************************

    # Return weighted r-Squared Value
    weighted_r_squared

    # # Predict Odometer Reading at Oil Change
    # Import Odometer Values into numpy Array
    odometer = df_interval_first.odometer.values
    odometer = odometer.reshape(-1, 1)

    # Compute Linear Regression Model
    regr_odometer = linear_model.LinearRegression(fit_intercept=True)
    regr_odometer.fit(odometer, t, sample_weight=w_exp)

    # Compute the Number of Days to Next Oil Change
    # NOTE: You Can Choose Any Value of next_oil_days to Determine Prediction of Odometer Reading at that Value
    # next_oil_days       = (next_oil_change - start_date).days
    next_oil_days = b[0]
    next_oil_days

    # Return Predicted Odometer for Next Oil Change
    #next_oil_odometer = (next_oil_days - regr_odometer.intercept_) / regr_odometer.coef_
    #next_oil_odometer[0][0]

    # Return Number of Days to Next Oil Change from Odometer Reading
    #next_oil_days = (next_oil_odometer * regr_odometer.coef_) + regr_odometer.intercept_
    #next_oil_days[0][0]

    # odo model params
    odo_slope = regr_odometer.coef_
    odo_intercept = regr_odometer.intercept_

    # # Upper Limits Calculations
    # Odometer slopes very close to zero will result in an undefined integer value when the
    # predicted odometer is calculated (division by zero)
    if odo_slope < 0.0001:
        next_oil_odometer = -1
    else:
        # num_days_to_when_odo_ready_for_oil_change = num_days_till_zero_oil_life = oil_intercept
        next_oil_odometer = (next_oil_days - odo_intercept) / odo_slope
        next_oil_odometer = next_oil_odometer[0][0]

    # Calculate upper limits for odometer & date of predicted oil life
    pred_date_limit = next_oil_change #predicted oil change date
    pred_odo_limit_if_under_max_km = int(next_oil_odometer)
    pred_odo_limit_if_above_max_km = int(next_oil_odometer)

    first_oil_life_date = df['first_ol_date'].values[0]
    first_oil_life_percent = df['first_ol_pct'].values[0]
    first_oil_life_percent = float(first_oil_life_percent)
    first_odometer = df['first_odometer'].values[0]
    first_odometer = int(first_odometer)

    if max_oil_change_cycle == 0:
        first_oil_life_percent = first_oil_life_percent / 100
        max_possible_days_till_oil_change = int(round(first_oil_life_percent * vehicle_date_limit))
        pred_date_limit = pd.to_datetime(first_oil_life_date) + dtm.timedelta(days=max_possible_days_till_oil_change)
        pred_date_limit = pred_date_limit.date()

        max_possible_km_till_oil_change_under = int(round(first_oil_life_percent * (vehicle_odometer_limit + 500)))
        pred_odo_limit_if_under_max_km = first_odometer + max_possible_km_till_oil_change_under

        max_possible_km_till_oil_change_above = int(round(first_oil_life_percent * vehicle_odometer_limit))
        pred_odo_limit_if_above_max_km = first_odometer + max_possible_km_till_oil_change_above

    elif max_oil_change_cycle >= 1:
        pred_date_limit = pd.to_datetime(first_oil_life_date) + dtm.timedelta(days=vehicle_date_limit)
        pred_date_limit = pred_date_limit.date()
        pred_odo_limit_if_under_max_km = first_odometer + vehicle_odometer_limit
        pred_odo_limit_if_above_max_km = first_odometer + vehicle_odometer_limit

    # Clip predicted date and odo if limits are exceeded - integration testing only
    if next_oil_change > pred_date_limit:
        next_oil_change =  pred_date_limit
    
    if (next_oil_odometer > pred_odo_limit_if_under_max_km) or (next_oil_odometer > pred_odo_limit_if_above_max_km):
        next_oil_odometer = pred_odo_limit_if_under_max_km

    return (r_squared, next_oil_change, next_oil_days, num_samples, next_oil_odometer, pred_odo_limit_if_under_max_km, pred_odo_limit_if_above_max_km, pred_date_limit)

    #add sample size, predicted date, and predicted odo number to output


def main():
    file_name = sys.argv[1]
    
    # Import Data File
    # Load and sort Data File
    df = pd.read_csv(file_name, sep=',')
    df = df.sort_values('trip_number', ascending=True)

    new_df = df.copy()
    new_df = new_df.assign(
        r_squared=None,
        predicted_date=None,
        oil_intercept_b=None,
        num_samples=None,
        predicted_odometer_km=None,
        pred_odo_limit_if_under_max_km=None,
        pred_odo_limit_if_above_max_km=None, 
        pred_date_limit=None)

    for row_index in range(1,len(df)+1):
        r_squared, next_oil_change, next_oil_days_b, num_samples, next_oil_odometer, pred_odo_limit_if_under_max_km, pred_odo_limit_if_above_max_km, pred_date_limit=get_model_params(df[:row_index])
        new_df.at[row_index-1, 'r_squared'] = r_squared
        new_df.at[row_index-1, 'predicted_date'] = next_oil_change
        new_df.at[row_index-1, 'oil_intercept_b'] = next_oil_days_b 
        new_df.at[row_index-1, 'num_samples'] = num_samples 
        new_df.at[row_index-1, 'predicted_odometer_km'] = next_oil_odometer
        new_df.at[row_index-1, 'pred_odo_limit_if_under_max_km'] = pred_odo_limit_if_under_max_km
        new_df.at[row_index-1, 'pred_odo_limit_if_above_max_km'] = pred_odo_limit_if_above_max_km
        new_df.at[row_index-1, 'pred_date_limit'] = pred_date_limit

    print(new_df.head(10))
    
    new_df = new_df.sort_values('trip_number', ascending=True)
    #change file output name to include VIN number and date maybe
    new_df.to_csv('out_int_tc2.csv')

if __name__ == "__main__":
    main()